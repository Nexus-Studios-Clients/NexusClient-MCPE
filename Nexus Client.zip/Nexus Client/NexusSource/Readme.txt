Créditos:
madson_1000
m4theus.wtfkkj
MIGUELH4CK_LDSJ/miguelrs2025__
no resources Arsc você pode pesquisar por "Nome do seu Client" e clique no bloco e apague esse texto e bote o nome do seu Client.
no Android manifest pesquisei por esses textos e siga Oque ele está pedindo
android:versionName="versão do seu Client!"
outro texto para pesquisar
android:label="nome do seu Client"
na pasta assets você pode trocar a textura pegando a pasta de outro assests do Client/APK que você escolheu e troque a pasta
apenas um tutorial básico:)